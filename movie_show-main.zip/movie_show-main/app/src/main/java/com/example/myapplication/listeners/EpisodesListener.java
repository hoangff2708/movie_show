package com.example.myapplication.listeners;

import com.example.myapplication.models.Episode;

public interface EpisodesListener {
    void onEpisodeClicked(Episode episode);
}