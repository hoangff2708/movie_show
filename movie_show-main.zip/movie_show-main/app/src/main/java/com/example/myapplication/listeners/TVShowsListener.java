package com.example.myapplication.listeners;

import com.example.myapplication.models.TVShow;

public interface TVShowsListener {
    void onTVShowClicked(TVShow tvShow);
}